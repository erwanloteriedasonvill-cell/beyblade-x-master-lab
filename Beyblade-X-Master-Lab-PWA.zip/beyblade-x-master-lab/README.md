# Beyblade X Master Lab — version indépendante 0.1

Application React/Vite avec configuration Capacitor pour préparer une application Android.

## Fonctionnalités présentes
- Interface mobile sombre, navigation Accueil / Catalogue / Créer / Combos / Données.
- Catalogue de départ **partiel et non certifié** de Blades, Ratchets et Bits.
- Ajout manuel de pièces.
- Création et sauvegarde locale des combos.
- Saisie de combats (adversaire, type adverse, stade, résultat, type de fin).
- Scores théoriques indicatifs, score réel provisoire, score global hybride.
- Export/import de sauvegarde JSON.

## Important
- Le catalogue de départ sert de squelette de travail, pas de liste officielle exhaustive. Vérifier les noms exacts, versions et caractéristiques avant d'en tirer des conclusions.
- L'algorithme des scores est un prototype heuristique, non une mesure compétitive validée. Il doit être calibré sur des résultats de combats réels.
- Les données sont enregistrées sur l'appareil dans `localStorage`. Elles ne se synchronisent pas entre plusieurs appareils.
- Les données Base44 ne sont **pas** importées automatiquement. Exporter les données depuis Base44 si une fonction d'export est disponible, puis adapter le fichier au format attendu.

## Lancer sur ordinateur
Installer Node.js LTS, puis dans ce dossier :
```bash
npm install
npm run dev
```

Pour vérifier la compilation web :
```bash
npm run build
```

## Préparer Android (APK)
Prérequis : Node.js LTS, Android Studio et Android SDK configuré.
```bash
npm install
npm run android:add
npm run android:sync
npm run android:open
```
Dans Android Studio, laisser Gradle synchroniser, puis utiliser **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Pour un APK de distribution, configurer une signature. Le fichier APK n'est pas inclus dans ce zip : il faut effectuer la compilation sur un environnement Android configuré.

## Import des données
Dans l'onglet Données, l'application peut importer son propre format JSON (`parts`, `combos`, `battles`). Les exports Base44 peuvent avoir une structure différente et nécessiter une conversion. Conserver une copie originale avant toute conversion.


## Utiliser depuis un téléphone Android sans ordinateur
Le projet est maintenant préparé comme application web installable (PWA). Il faut d'abord publier le dossier sur un hébergement HTTPS (par exemple GitHub Pages via un dépôt, ou un hébergeur statique). Ouvrir ensuite l'adresse publiée dans Chrome sur Android, menu ⋮ → **Installer l'application** ou **Ajouter à l'écran d'accueil**. Une simple ouverture du ZIP dans le téléphone ne suffit pas pour installer l'application.

Cette version PWA n'est pas un APK. La création d'un APK natif nécessite une compilation Android, qui peut être faite sur un service cloud mais demande une configuration de dépôt et de build.


## Compilation APK dans le cloud depuis un téléphone
Le dossier `.github/workflows/android-apk.yml` lance une compilation Android debug sur GitHub Actions. Après avoir importé les fichiers du projet dans un dépôt GitHub, ouvrir l'onglet **Actions**, choisir **Build Android APK**, appuyer sur **Run workflow**, puis télécharger l'artefact `beyblade-x-master-lab-debug-apk` quand le travail est terminé. Le premier lancement doit être surveillé pour corriger tout problème éventuel de compilation. L'APK debug est destiné aux tests, pas à une publication officielle.
